from re import A
import discord
import asyncio
import random as rd
from discord import message
from discord import reaction as rt
from discord import embeds
from discord.colour import Color
from discord.ext import commands
from discord.ext.commands.core import check
from psutil import users

class CogOwner(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
    async def cog_check(self, ctx):
        try:
            return 
        except:
            embed = discord.Embed(title="**Missing Riquired Permissions**", color=0xFF0000)
            embed.set_thumbnail(url="https://emoji.gg/assets/emoji/5099-no.png")
            embed.add_field(name="Warning", value="*Oops tu n'as pas les permissions requises pour faire cette commande dommage.*", inline=True)
            
            
            await ctx.send(embed=embed)
    
    @commands.command()
    @commands.has_permissions(manage_messages = True)
    async def clear(ctx, number : int):
        messages = await ctx.channel.history(limit = number + 1).flatten()
        for message in messages:
            await message.delete()
    @clear.error
    async def clear_error(ctx, error):
        if isinstance(error, commands.MissingRequiredArgument):
            embed = discord.Embed(title="**Missing Riquired Argument**", color=0xFF0000)
            embed.set_author(name=ctx.author.name, icon_url=ctx.author.avatar_url)
            embed.set_thumbnail(url="https://emoji.gg/assets/emoji/5099-no.png")
            embed.add_field(name="**Warning**", value="Oops la commande  *$clear*  prend obligatoirement un argument !\n*E.x: '$clear 10'*", inline=True)
        
        
        await ctx.send(embed=embed)
    
    @commands.command()
    @commands.has_permissions(kick_members = True)
    async def kick(ctx, user : discord.User, *, reason="Aucune raison n'a été donnée."):
        reason = " ".join(reason)
        #await ctx.guild.kick(user, reason = reason)
        embed = discord.Embed(title="**Expulsion**", description="La sentance est tombé !", color=0x00FFFF)
        embed.set_author(name=ctx.author.name, icon_url=ctx.author.avatar_url)
        embed.set_thumbnail(url="https://emoji.gg/assets/emoji/9597-amonguskickicon.png")
        embed.add_field(name="Membre expulsé", value=user.name, inline=True)
        embed.add_field(name="Raison", value=reason, inline=False)
        embed.add_field(name="Modérateur", value=ctx.author.name, inline=False)
    
        await ctx.send(embed=embed)
        
    @commands.command()
    @commands.has_permissions(ban_members = True)
    async def ban(ctx, user : discord.User, *, reason="Aucune raison n'a été donnée."):
        reason = " ".join(reason)
        await ctx.guild.ban(user, reason = reason)
        embed = discord.Embed(title = "**Bannissement**", description = "La sentance est tombé !", color=0x00FFFF)
        embed.set_author(name=ctx.author.name, icon_url=ctx.author.avatar_url)
        embed.set_thumbnail(url="https://discordemoji.com/assets/emoji/BanneHammer.png")
        embed.add_field(name="Membre banni", value=user.name, inline=True)
        embed.add_field(name="Raison", value=reason, inline=True)
        embed.add_field(name="Modérateur", value=ctx.author.name, inline=False)

        await ctx.send(embed = embed)
    
    @commands.command()
    async def unban(ctx, user, *, reason="Aucune raison n'a été donnée."):
        reason = " ".join(reason)
        user_name, user_id = user.split("#")
        banne_users =  await ctx.guild.bans()
        for i in banne_users:
            if i.user.name == user_name and i.user.discriminator == user_id:
                await ctx.guild.unban(i.user, reason = reason)
                embed = discord.Embed(title="**Débannissement**", color=0x2ECC71)
                embed.set_author(name=ctx.author.name, icon_url=ctx.author.avatar_url)
                embed.add_field(name="Membre banni", value=user.name, inline=True)
                embed.add_field(name="Raison", value=reason, inline=False)
                embed.add_field(name="Modérateur", value=ctx.author.name, inline=False)


                await ctx.send(embed=embed)
                return
        # ici on sait que l'utilisateur n'a pas ete trouve
        await ctx.send(f"{user} n'est pas dans la liste des bans")